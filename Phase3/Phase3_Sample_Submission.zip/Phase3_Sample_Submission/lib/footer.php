			
            <div id="footer"> 
                <div class="footer">  
				
				
                	<div class="resource_title">Resources:</div>
					
                    <ul>        
                    
					<li><a href="http://www.w3schools.com/"  target="_blank">http://www.w3schools.com/</a></li>
                    <li><a href="http://www.agiledata.org/essays/keys.html"  target="_blank">http://www.agiledata.org/essays/keys.html</a></li>                       
                    <li><a href="http://www.w3resource.com/sql-exercises/"  target="_blank">http://www.w3resource.com/sql-exercises/</a></li>  
                    <li><a href="https://bitnami.com/stacks/infrastructure"  target="_blank">https://bitnami.com/stacks/infrastructure</a></li>       
                    <li><a href="https://www.jetbrains.com/phpstorm/"  target="_blank">https://www.jetbrains.com/phpstorm/</a></li>
                    <li><a href="https://www.w3schools.com/w3css/w3css_templates.asp"  target="_blank">https://www.w3schools.com/w3css/w3css_templates.asp</a></li>  
                    <li><a href="https://v4-alpha.getbootstrap.com/components/forms/"  target="_blank">https://v4-alpha.getbootstrap.com/components/forms/</a></li>          
                    <li><a href="http://www.cs.montana.edu/~halla/csci440/index.html"  target="_blank">http://www.cs.montana.edu/~halla/csci440/index.html</a></li>  
                    <li><a href="https://lagunita.stanford.edu/courses/Engineering/db/2014_1/about"  target="_blank">https://lagunita.stanford.edu/courses/Engineering/db/2014_1/about</a></li>                     
                    <li><a href="http://web.stanford.edu/class/cs145/"  target="_blank">http://web.stanford.edu/class/cs145/</a></li> 
                   
					</ul>
				
				</div>
            </div>	 

