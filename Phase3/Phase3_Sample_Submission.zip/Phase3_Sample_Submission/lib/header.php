<!DOCTYPE html>  <!-- HTML 5 -->
	<head>
		<link rel="shortcut icon" href="img/gtonline_icon.png">
		<link rel="stylesheet" type="text/css" href="css/gtonline_style.css" />
        <meta http-equiv="Content-Type" content="text/html; charset="UTF-8" />
        <link rel="shortcut icon" type="image/png" href="img/gtonline_icon.png"/>